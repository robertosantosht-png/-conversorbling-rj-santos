import pandas as pd
import openpyxl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import smtplib
import logging
import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

# Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = FastAPI()

class ConverterRequest(BaseModel):
    email_destino: str
    planilha_path: str

def enviar_email(destinatario: str, assunto: str, corpo: str, anexo: Optional[str] = None):
    gmail_user = os.getenv('GMAIL_USER')
    if not gmail_user:
        logging.error("Env var GMAIL_USER ausente.")
        raise ValueError("Env var GMAIL_USER ausente.")
    
    print(f"[SIMULADO] De: {gmail_user}")
    print(f"[SIMULADO] Para: {destinatario}")
    print(f"[SIMULADO] Assunto: {assunto}")
    print(f"[SIMULADO] Corpo:\n{corpo}")
    if anexo:
        print(f"[SIMULADO] Anexo: {anexo}")
    logging.info(f"[SIMULADO] Enviado para {destinatario}")

def ler_template(nome: str) -> str:
    with open(f"{nome}.txt", 'r', encoding='utf-8') as f:
        return f.read()

@app.post("/converter")
async def converter(req: ConverterRequest):
    try:
        # Email inicial
        enviar_email(req.email_destino, 'Iniciado - Conversor Bling', ler_template('index'))
        
        # Lê planilha
        if req.planilha_path.endswith('.csv'):
            df = pd.read_csv(req.planilha_path)
        else:
            df = pd.read_excel(req.planilha_path, engine='openpyxl')
        
        # Email progresso
        enviar_email(req.email_destino, 'Processando - Conversor Bling', ler_template('main'))
        
        # Converte para Bling (ajuste colunas)
        df_bling = df[['Produto', 'SKU', 'Preço', 'Estoque']]  # Exemplo; adapte
        output = 'planilha_convertida.xlsx'
        df_bling.to_excel(output, index=False, engine='openpyxl')
        
        # Email sucesso + anexo
        enviar_email(req.email_destino, 'Concluído - Conversor Bling', ler_template('sucesso'), output)
        
        return {"status": "sucesso", "arquivo": output}
    except Exception as e:
        logging.error(str(e))
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)